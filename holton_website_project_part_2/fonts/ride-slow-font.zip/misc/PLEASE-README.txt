Thank you for download the font. This font is for PERSONAL USE ONLY. For any commercial use, you can download the full license here :

https://konstantinestudio.com/

and we’re available in other stores below :
https://creativemarket.com/konstantinestudio
http://www.myfonts.com/foundry/KonstantineStudio/


Thanks a lot!

Warm regards,
Konstantine Studio